<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="ja">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="ja">
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html lang="ja">
<![endif]-->
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="兵庫県姫路市で寿司屋をお探しならJR姫路駅徒歩7分の「雷寿司」へ">
    <meta name="keywords" content="兵庫県,姫路市,姫路駅,雷寿司,寿司,sushi,美味しい,おすすめ,寿司屋,新鮮,口コミ">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Popover%20Requires%20Tooltip Js に何も見つかりません</title>

    <!--Font Awesome-->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <script src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/js/css3-mediaqueries.js"></script>
    <![endif]-->

  <link rel="shortcut icon" href="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/favicon.ico">



<!-- All in One SEO Pack 2.3.13.2 by Michael Torbert of Semper Fi Web Design[663,692] -->
			<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-93894916-17', 'auto');
			
			ga('send', 'pageview');
			</script>
<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.kaminarizushi.jp\/wp\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.29"}};
			!function(t,a,e){var r,n,i,o=a.createElement("canvas"),l=o.getContext&&o.getContext("2d");function c(t){var e=a.createElement("script");e.src=t,e.defer=e.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(e)}for(i=Array("flag","emoji4"),e.supports={everything:!0,everythingExceptFlag:!0},n=0;n<i.length;n++)e.supports[i[n]]=function(t){var e,a=String.fromCharCode;if(!l||!l.fillText)return!1;switch(l.clearRect(0,0,o.width,o.height),l.textBaseline="top",l.font="600 32px Arial",t){case"flag":return(l.fillText(a(55356,56826,55356,56819),0,0),o.toDataURL().length<3e3)?!1:(l.clearRect(0,0,o.width,o.height),l.fillText(a(55356,57331,65039,8205,55356,57096),0,0),e=o.toDataURL(),l.clearRect(0,0,o.width,o.height),l.fillText(a(55356,57331,55356,57096),0,0),e!==o.toDataURL());case"emoji4":return l.fillText(a(55357,56425,55356,57341,8205,55357,56507),0,0),e=o.toDataURL(),l.clearRect(0,0,o.width,o.height),l.fillText(a(55357,56425,55356,57341,55357,56507),0,0),e!==o.toDataURL()}return!1}(i[n]),e.supports.everything=e.supports.everything&&e.supports[i[n]],"flag"!==i[n]&&(e.supports.everythingExceptFlag=e.supports.everythingExceptFlag&&e.supports[i[n]]);e.supports.everythingExceptFlag=e.supports.everythingExceptFlag&&!e.supports.flag,e.DOMReady=!1,e.readyCallback=function(){e.DOMReady=!0},e.supports.everything||(r=function(){e.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",r,!1),t.addEventListener("load",r,!1)):(t.attachEvent("onload",r),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&e.readyCallback()})),(r=e.source||{}).concatemoji?c(r.concatemoji):r.wpemoji&&r.twemoji&&(c(r.twemoji),c(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='bootstrap-css'  href='http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/css/main.css' type='text/css' media='all' />
<link rel='stylesheet' id='stylies-css'  href='http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/style.css' type='text/css' media='all' />
<script type='text/javascript' src='http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/js/jquery-1.12.3.min.js'></script>
<script type='text/javascript' src='http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/js/bootstrap.min.js?ver=4.7.29'></script>
<link rel='https://api.w.org/' href='http://www.kaminarizushi.jp/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.kaminarizushi.jp/wp/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.kaminarizushi.jp/wp/wp-includes/wlwmanifest.xml" /> 
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		  </head>
  <body class="error404">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.8&appId=133455143677459";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


  <header>
  <div id="wrap" class="head container">
    <h1 class="cleartext">兵庫県姫路市で寿司屋をお探しならJR姫路駅徒歩7分の「雷寿司」へ</h1>



  <div class="row">
  <div class="head__logo col-md-4 col-md-offset-4">
    <h2><a href="http://www.kaminarizushi.jp"><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/logo.png" alt="雷寿司" /></a></h2>
  </div>
  <div class="col-md-4 head__tel">
  <img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/head_tel.png" alt="雷寿司 ご予約・お問い合わせ 電話番号079-223-6812 営業時間 17:00～24:00 定休日 日曜日・祝日" />
  <div class="head__img">
    <!--Yahoo! Reservation Tag Manager-->
    <script type="text/javascript">YAHOO=window.YAHOO||{};YAHOO.JP=YAHOO.JP||{};YAHOO.JP.gmtr=YAHOO.JP.gmtr||{};YAHOO.JP.gmtr.tag={id:'03',url:'https://r.reservation.yahoo.co.jp/reserve/input/s000138545',type:'a'};</script> <script type="text/javascript" src="https://s.yimg.jp/images/reservation/rm/assets/pc/0-0-2/js/tag-min.js"></script>
    <!--/Yahoo! Reservation Tag Manager-->
  </div>
  </div>
  </div>
  <!-- .container-fluid end-->
  </div>

<!-- gloval nav start-->
<!-- グローバルメニュー-->
<div class="">
<nav class="navbar navbar-default m0" role="navigation">
            <!-- gloval nav-->
              <!-- スマートフォンサイズで表示されるメニューボタンとテキスト -->
              <div class="navbar-header">

                <!--メニューボタン
                  data-toggle : ボタンを押したときにNavbarを開かせるために必要
                  data-target : 複数navbarを作成する場合、ボタンとナビを紐づけるために必要
                -->
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-menu-1">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>

                <!-- タイトルなどのテキスト -->
                <!--<a class="navbar-brand" href="#">Designup.jp</a>-->
              </div>

<div class="container">
<div class="row">
<div id="nav-menu-1" class="collapse navbar-collapse"><ul id="header-gloval" class="nav navbar-nav"><li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-20"><a title="ホーム"  title="menu_home.png" href="http://www.kaminarizushi.jp/""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_home.png" alt="*" /></a></li>
<li id="menu-item-25" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25"><a title="始めての方へ"  title="menu_beginners.png" href="http://www.kaminarizushi.jp/beginners""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_beginners.png" alt="*" /></a></li>
<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a title="お品書き"  title="menu_menu.png" href="http://www.kaminarizushi.jp/menu""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_menu.png" alt="*" /></a></li>
<li id="menu-item-27" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27"><a title="当店への道案内"  title="menu_guide.png" href="http://www.kaminarizushi.jp/guide""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_guide.png" alt="*" /></a></li>
<li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a title="店舗概要"  title="menu_about.png" href="http://www.kaminarizushi.jp/about""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_about.png" alt="*" /></a></li>
<li id="menu-item-39" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-39"><a title="ブログ"  title="menu_blog.png" href="http://www.kaminarizushi.jp/category/cat_blog""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_blog.png" alt="*" /></a></li>
<li id="menu-item-40" class="menu-item menu-item-type-post_type_archive menu-item-object-news menu-item-40"><a title="お知らせ"  title="menu_news.png" href="http://www.kaminarizushi.jp/newslist""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_news.png" alt="*" /></a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a title="お問合せ"  title="menu_contact.png" href="http://www.kaminarizushi.jp/contact""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_contact.png" alt="*" /></a></li>
<li id="menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a title="facebook"  title="menu_fb.png" target="_blank" href="https://www.facebook.com/kaminarizushi/""><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/menu_fb.png" alt="*" /></a></li>
</ul></div></div>
</nav>
</div>
</div>
<!-- //グローバルメニュー-->
<!-- gloval nav end-->




</header>


<aside>
    <div class="container-fluid">
    <div class="row">



<div  id="post-"  class="container p- Page">
<div class="row">
    <div class="main-content">
    <main>
<!--/*▼基本的にここから下を編集*/-->

      <!--ここはメイン-->
      <section>
          <div class="post">
     <h2>Not Found</h2>
   <p>ごめんなさい ... 記事がありませんでした ...</p>
</div>      </section>
    <!--//特定記事カテゴリ抽出｜最新記事除外-->

<!-- pagination -->
<p>Sorry, no posts matched your criteria.</p>
<!-- /pagination -->

<!--/*▼基本的にここから上を編集*/-->
<!-- .main-content end-->
</main>
</div>
</div><!-- //.row end-->
</div><!-- //.container end-->



<!-- .row end-->
</div>
</div>
</aside>

<div class="container">
<div class="goto__block"><a id="page-top" href="#wrap"><img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/go_to_top.png" alt="雷寿司 ページの先頭へ" /></a></div>
</div>


<footer>
  <div class="container">
  <!-- フッターメニュー-->
  <div id="footernav" class="list-group"><ul id="footerlist" class="footermenu footernavbar"><li id="menu-item-47" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-47"><a href="http://www.kaminarizushi.jp/">ホーム</a></li>
<li id="menu-item-52" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-52"><a href="http://www.kaminarizushi.jp/beginners">初めての方へ</a></li>
<li id="menu-item-48" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a href="http://www.kaminarizushi.jp/menu">お品書き</a></li>
<li id="menu-item-54" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-54"><a href="http://www.kaminarizushi.jp/guide">当店への道案内</a></li>
<li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-53"><a href="http://www.kaminarizushi.jp/about">店舗概要</a></li>
<li id="menu-item-55" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-55"><a href="http://www.kaminarizushi.jp/category/cat_blog">ブログ</a></li>
<li id="menu-item-56" class="menu-item menu-item-type-post_type_archive menu-item-object-news menu-item-56"><a href="http://www.kaminarizushi.jp/newslist">お知らせ</a></li>
<li id="menu-item-49" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a href="http://www.kaminarizushi.jp/contact">お問合せ</a></li>
</ul></div>  <!-- //フッターメニュー-->
  </div>

<div class="footer__logoblock">
<div class="line__pt"></div>
<div class="footer__logo">
<img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/footer_logo.png" alt="雷寿司" />
</div>
</div>


<div class="footer__info--wrap">

<div class="container">

  <div class="footer__info">

      <div class="footer__title">
        <h2>雷寿司</h2>
      </div>

      <div class="footer__address">
      〒670-0905　兵庫県姫路市魚町2番地　第5クリスタルビル1F
      </div>

      <div class="footer__tel">
      <img class="img-responsive" src="http://www.kaminarizushi.jp/wp/wp-content/themes/wp_kaminari/images/footer_tel.png" alt="雷寿司 ご予約・お問い合わせ 電話番号 079-223-6812 営業時間 18:00～翌2:00 定休日 日曜日・祝日" />
      </div>

  </div>

</div>

</div><!-- footer__info--wrap -->

<div class="copyright-box">
<div class="container">
<p class="copyright text-center">Copyright &copy;2025 雷寿司 All rights Reserved.</p>
</div>
</div>


</footer>
    <script>
    /*TOPへ戻る*/
    $(function() {
    var topBtn = $('#page-top');
    topBtn.hide();
    //スクロールが100に達したらボタン表示
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            topBtn.fadeIn().css('display','inline-block');
        } else {
            topBtn.fadeOut();
        }
    });
    //スクロールしてトップ
    topBtn.click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 1000);
        return false;
    });
    });
    </script>

<script type='text/javascript' src='http://www.kaminarizushi.jp/wp/wp-includes/js/wp-embed.min.js?ver=4.7.29'></script>
  </body>
</html>